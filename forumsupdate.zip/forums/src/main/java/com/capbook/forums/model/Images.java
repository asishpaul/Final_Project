package com.capbook.forums.model;

import java.io.File;                                                                                                


import javax.persistence.Entity;                                                                                    
import javax.persistence.GeneratedValue;                                                                            
import javax.persistence.Id;                                                                                        
import javax.persistence.Transient;                                                                                 
                                                                                                                    
@Entity                                                                                                             
public class Images {                                                                                               
                                                                                                                    
	@Id                                                                                                             
	@GeneratedValue                                                                                                 
	private Integer ImageId;                                                                                        
	private String PostDisc;                                                                                        
	private String ImageUrl;                                                                                        
	                                                                                                                
	@Transient                                                                                                      
	private File file;                                                                                              
                                                                                                                    
	public Images(Integer imageId, String postDisc, String imageUrl, File file) {                                   
		super();                                                                                                    
		ImageId = imageId;                                                                                          
		PostDisc = postDisc;                                                                                        
		ImageUrl = imageUrl;                                                                                        
		this.file = file;                                                                                           
	}                                                                                                               
	                                                                                                                
                                                                                                                    
	public Images(String postDisc, File file) {                                                                     
		super();                                                                                                    
		PostDisc = postDisc;                                                                                        
		this.file = file;                                                                                           
	}                                                                                                               
                                                                                                                    
                                                                                                                    
	public Images() {                                                                                               
		                                                                                                            
	}                                                                                                               
                                                                                                                    
	public Integer getImageId() {                                                                                   
		return ImageId;                                                                                             
	}                                                                                                               
                                                                                                                    
	public void setImageId(Integer imageId) {                                                                       
		ImageId = imageId;                                                                                          
	}                                                                                                               
                                                                                                                    
	public String getPostDisc() {                                                                                   
		return PostDisc;                                                                                            
	}                                                                                                               
                                                                                                                    
	public void setPostDisc(String postDisc) {                                                                      
		PostDisc = postDisc;                                                                                        
	}                                                                                                               
                                                                                                                    
	public String getImageUrl() {                                                                                   
		return ImageUrl;                                                                                            
	}                                                                                                               
                                                                                                                    
	public void setImageUrl(String imageUrl) {                                                                      
		ImageUrl = imageUrl;                                                                                        
	}                                                                                                               
                                                                                                                    
	public File getFile() {                                                                                         
		return file;                                                                                                
	}                                                                                                               
                                                                                                                    
	public void setFile(File file) {                                                                                
		this.file = file;                                                                                           
	}                                                                                                               
                                                                                                                    
	@Override                                                                                                       
	public String toString() {                                                                                      
		return "Images [ImageId=" + ImageId + ", PostDisc=" + PostDisc + ", ImageUrl=" + ImageUrl + ", file=" + file
				+ "]";                                                                                              
	}               
}