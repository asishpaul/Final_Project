package com.capbook.forums.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capbook.forums.model.Group_Topic;

@Repository("groupTopicDao")
@Transactional
public interface IGroupTopicDao extends JpaRepository<Group_Topic, Integer>{

}
