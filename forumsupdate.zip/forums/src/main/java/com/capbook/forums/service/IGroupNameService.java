package com.capbook.forums.service;

public interface IGroupNameService {

}
