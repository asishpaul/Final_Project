import { Component, OnInit } from '@angular/core';
import { IGroup, IPostT } from '../../api/groups/groups';
import { IFriends } from '../../api/group-profile/friends';
import { GroupsService } from '../../api/groups/groups.service';
import { group_request } from '../../api/group-profile/friends';
import { GroupProfileService } from '../../api/group-profile/group-profile.service';
@Component({
  selector: 'pm-group-profile',
  templateUrl: './group-profile.component.html',
  styleUrls: ['./group-profile.component.css']
})
export class GroupProfileComponent implements OnInit {
 
  public pageTitle: string='groupProfile';
  
  public groupNme:string;
  postT:IPostT=new IPostT();
  topic:IPostT[]=[];
  errorMessage:string;
  members:boolean=false;
  groupJoin:boolean=false;

  gmembers:IFriends[]=[];
groups:IGroup=  new IGroup();
  _postPhoto:boolean=false;
  _postTopic:boolean=false;
message:string;
addRequest:group_request={
  g_requestId:0,
	groupId:0,
  userId:0,
  status:"Pending"
  
}
  constructor(private _groupService:GroupsService,private _groupProfileService:GroupProfileService) { }

  ngOnInit() {
    this.groupNme=GroupsService.gName;
    this._groupProfileService.getFriends().subscribe(gmembers=> {this.gmembers=gmembers;
    
  },
  error=>this.errorMessage=<any>error
       );
      }
      deleteFriends(userId:number){
        this._groupProfileService.deleteFriends(userId).subscribe(gmembers=> {this.gmembers=gmembers;
    
        },
        error=>this.errorMessage=<any>error
             );
            }
  postPhoto():void{
    this._postPhoto=true;
    this._postTopic=false;
    }
  postTopic():void{
    this._postTopic=true;
    this._postPhoto=false;
    
  }  
  afterPost():void{
    this._postPhoto=false;
    this._postTopic=false;
    this._groupService.postT(this.postT).subscribe(topic=>{this.topic=topic;},
 
      error=>this.errorMessage=<any>error);
    
    
    }
  flag:boolean=false;
  flag1:boolean=false;
  flag2:boolean=false;
  onClick1():void{
    this.flag2=true;
  }


    onClic():void{
      this.flag=true;
    }

    toggleImage():void{

      this.groupJoin=!this.groupJoin
    }
    toggleImage1():void{
      this.members=!this.members
    }
    addFriends(){
      this.addRequest.groupId=GroupsService.groupID;
      
      this._groupProfileService.addFriends(this.addRequest).subscribe(groupRequests=>console.log(groupRequests))

    }
  }
  
