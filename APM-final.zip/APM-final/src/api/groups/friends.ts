 export interface IFriend{

    friendName:string

   
} 