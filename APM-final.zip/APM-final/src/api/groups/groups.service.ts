import { Injectable } from "@angular/core";
import { IFriend } from "./friends";
import { HttpClient, HttpErrorResponse, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs/Observable";
import "rxjs/add/observable/throw";
import "rxjs/add/operator/do";
import "rxjs/add/operator/catch";
import { IGroup, IPostT, IGroup1 ,IGroup2} from "./groups";
import { Subject } from "../../../node_modules/rxjs/Subject";
import { BehaviorSubject } from 'rxjs';
import { group } from "../../../node_modules/@angular/core/src/animation/dsl";
import { getTypeNameForDebugging } from "../../../node_modules/@angular/core/src/change_detection/differs/iterable_differs";

const httpOptions ={
    headers :new HttpHeaders({'Content-Type':'application/json'})
};
@Injectable()
export class GroupsService{
    private _friendUrl='http://localhost:8083/groups';
    _Url:string='http://localhost:8083/groups';
/*     private friend:IFriend;
 */    private getAllFriends:string='findall';
 public static gName:string;
 public static groupID:number;
 private subject = new Subject<any>();
 /* sendMessage(gName){
     this.subject.next({text:gName}); }
     clearMessage(){
         this.subject.next();
     }
     getMessage():Observable<any>{
         return this.subject.asObservable();

     } */
   
     
   
    constructor(private _http:HttpClient){

    }
    
 

    getFriends():Observable<IFriend[]>{
        this._friendUrl =this._Url+ '/'+this.getAllFriends;
        return  this._http.get<IFriend[]>(this._friendUrl)
 
    }
    createGroup(group:IGroup):Observable<IGroup[]>
    {
       
       GroupsService.gName=group.groupName;
    
        this._friendUrl =this._Url+ '/'+'creategroup';
       // groupList:IGroup[] =this._http.post<IGroup[]>(this._friendUrl,group);
        return  this._http.post<IGroup[]>(this._friendUrl,group)

        
    }
    postT(postT:IPostT):Observable<IPostT[]>
    {
       
     
    
        this._friendUrl =this._Url+ '/'+'postT';
        return  this._http.post<IPostT[]>(this._friendUrl,postT)
    }
    getGroups(groupAdmin:number){

        this._friendUrl=this._Url+'/'+'groupadmin'+'/'+groupAdmin;
        return this._http.get<IGroup1[]>(this._friendUrl)

}
getJoinedGroups(userId:number){
    this._friendUrl=this._Url+'/'+'groups'+'/'+userId;
    return this._http.get<IGroup2[]>(this._friendUrl)

}
}