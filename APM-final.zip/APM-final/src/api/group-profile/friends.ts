export interface IFriends{
    id:number;
    friendName:string

   
}
export interface group_request{
    
  g_requestId:number;
	groupId:number;
	userId:Number;
	status:string;    

}