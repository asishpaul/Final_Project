import { Injectable } from "@angular/core";
import { ICustomer } from "./customer";
import { HttpClient, HttpErrorResponse, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs/Observable";
import "rxjs/add/observable/throw";
import "rxjs/add/operator/do";
import "rxjs/add/operator/catch";

const httpOptions ={
    headers :new HttpHeaders({'Content-Type':'application/json'})
};
@Injectable()
export class CustomerService{
    private _productUrl='http://localhost:8084/day3-Spring5Rest/api/customers';
    _Url:string
    private customer:ICustomer;
    constructor(private _http:HttpClient){

    }
    getProducts():Observable<ICustomer[]>{
        return  this._http.get<ICustomer[]>(this._productUrl)
        
       
    }
    deleteCustomers(customerId:number):Observable<ICustomer[]>
    {
        this._Url=this._productUrl+'/'+customerId
        return this._http.delete<ICustomer[]>(this._Url)
    }
    private handleError(err:HttpErrorResponse){
        console.error(err.message)
        return Observable.throw(err.message)
    }
    createCustomers(customer:ICustomer):Observable<ICustomer[]>
    {
        console.log(customer);
        return  this._http.post<ICustomer[]>(this._productUrl,customer)
    }
    getcustomer(customerId:number):Observable<ICustomer[]>{
        this._Url=this._productUrl+'/'+customerId
        //this.customer=this._http.get<ICustomer[]>(this._Url)
        return  this._http.get<ICustomer[]>(this._Url)
        
       
    }
    editCustomers(customer:ICustomer):Observable<ICustomer[]>
    {
       
        return this._http.put<ICustomer[]>(this._productUrl,customer,{})
    }
}