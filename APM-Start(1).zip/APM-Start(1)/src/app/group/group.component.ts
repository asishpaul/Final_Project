import { Component, OnInit } from '@angular/core';
import { GroupsService } from '../../api/groups/groups.service';
import { IFriend } from '../../api/groups/friends';


@Component({
   selector: 'app-group', 
  templateUrl: './group.component.html',
  styleUrls: ['./group.component.css']
})
export class GroupComponent implements OnInit {
  
  friends:IFriend[]=[];

  errorMessage:string;

  public pageTitle: string='create';

   
  flag:boolean=false;
  showFriends:boolean=false;
    onClick():void{
      this.flag=true;
    }
   

constructor(private _groupService:GroupsService) { }



  ngOnInit() {
       console.log('In OnInit')
      this._groupService.getFriends().subscribe(friends=> {
        this.friends=friends;
        
 },
 error=>this.errorMessage=<any>error
      );
     
    
}
toggleImage():void{
  this.showFriends=!this.showFriends
}
}
