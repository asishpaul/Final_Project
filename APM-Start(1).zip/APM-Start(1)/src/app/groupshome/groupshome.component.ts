import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pm-groupshome',
  templateUrl: './groupshome.component.html',
  styleUrls: ['./groupshome.component.css']
})
export class GroupshomeComponent implements OnInit {
  public pageTitle: string='groupshome';
  
  
  constructor() { }

  ngOnInit() {
  }

}
