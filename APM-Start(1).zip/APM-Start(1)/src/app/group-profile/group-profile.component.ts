import { Component, OnInit } from '@angular/core';
import { IFriend } from '../../api/groups/friends';
import { GroupsService } from '../../api/groups/groups.service';
import { GroupProfileService } from '../../api/group-profile/group-profile.service';

@Component({
  selector: 'pm-group-profile',
  templateUrl: './group-profile.component.html',
  styleUrls: ['./group-profile.component.css']
})
export class GroupProfileComponent implements OnInit {
  friends:IFriend[]=[];

  public pageTitle: string='groupProfile';

  errorMessage:string;
  _postPhoto:boolean=false;
  _postTopic:boolean=false;

  flag2:boolean=false;
  members:boolean=false;
    onClick1():void{
      this.flag2=true;
    }

  flag1:boolean=false;
  groupJoin:boolean=false;
    onClick():void{
      this.flag1=true;
    }

  constructor(private _groupService:GroupsService,private _groupProfileService:GroupProfileService) { }

  ngOnInit() {
    this._groupService.getFriends().subscribe(friends=> {
      this.friends=friends;
  },
  error=>this.errorMessage=<any>error
       );
      
     
}
deleteFriends(userId:number){
  this._groupProfileService.deleteFriends(userId).subscribe(friends=> {
    this.friends=friends;})
}

  postPhoto():void{
    this._postPhoto=true;
    this._postTopic=false;
    }
  postTopic():void{
    this._postTopic=true;
    this._postPhoto=false;
  }  
  afterPost():void{
    this._postPhoto=false;
    this._postTopic=false;
  }

  flag:boolean=false;
  
    onClic():void{
      this.flag=true;
    }
    toggleImage():void{
      this.groupJoin=!this.groupJoin
    }
    toggleImage1():void{
      this.members=!this.members
    }
}
