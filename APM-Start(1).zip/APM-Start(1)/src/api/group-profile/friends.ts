export interface IFriend{
    id:number;
    friendName:string

   
}