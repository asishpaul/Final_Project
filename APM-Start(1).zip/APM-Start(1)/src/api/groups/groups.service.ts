import { Injectable } from "@angular/core";
import { IFriend } from "./friends";
import { HttpClient, HttpErrorResponse, HttpHeaders } from "@angular/common/http";
import { Observable } from "rxjs/Observable";
import "rxjs/add/observable/throw";
import "rxjs/add/operator/do";
import "rxjs/add/operator/catch";

const httpOptions ={
    headers :new HttpHeaders({'Content-Type':'application/json'})
};
@Injectable()
export class GroupsService{
    private _friendUrl='http://localhost:8083/groups';
    _Url:string='http://localhost:8083/groups';
/*     private friend:IFriend;
 */    private getAllFriends:string='findall';
    constructor(private _http:HttpClient){

    }
    getFriends():Observable<IFriend[]>{
        this._friendUrl =this._Url+ '/'+this.getAllFriends;
        return  this._http.get<IFriend[]>(this._friendUrl)
 
    }
    /* deleteCustomers(customerId:number):Observable<ICustomer[]>
    {
        this._Url=this._productUrl+'/'+customerId
        return this._http.delete<ICustomer[]>(this._Url)
    }
    private handleError(err:HttpErrorResponse){
        console.error(err.message)
        return Observable.throw(err.message)
    }
    createCustomers(customer:ICustomer):Observable<ICustomer[]>
    {
        console.log(customer);
        return  this._http.post<ICustomer[]>(this._productUrl,customer)
    }
    getcustomer(customerId:number):Observable<ICustomer[]>{
        this._Url=this._productUrl+'/'+customerId
        //this.customer=this._http.get<ICustomer[]>(this._Url)
        return  this._http.get<ICustomer[]>(this._Url)
        
       
    }
    editCustomers(customer:ICustomer):Observable<ICustomer[]>
    {
       
        return this._http.put<ICustomer[]>(this._productUrl,customer,{})
    } */
}